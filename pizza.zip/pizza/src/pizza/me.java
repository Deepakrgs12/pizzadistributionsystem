package pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class me
 */
public class me extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection c;
	PreparedStatement ps;
	ResultSet rs;
	
	private static java.sql.Timestamp getCurrentTimeStamp() {

		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		int k;
		   HttpSession session=request.getSession(false);
		      String myName=(String)session.getAttribute("uname");
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		//out.println("hello"+myName);
		String userid=request.getParameter("eid");
				int pass=Integer.parseInt(request.getParameter("pass"));
				out.println("<html><head><title>A.D king</title><meta charset=\"utf-8\">\r\n" + 
						"    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\r\n" + 
						"    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no\">\r\n" + 
						"\r\n" + 
						"    <!-- css -->\r\n" + 
						"    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\">\r\n" + 
						"    <link rel=\"stylesheet\" href=\"css/bootstrap-theme.min.css\">\r\n" + 
						"    <link rel=\"stylesheet\" href=\"css/font-awesome.min.css\">\r\n" + 
						"    <link rel=\"stylesheet\" href=\"css/main.css\">\r\n" + 
						"\r\n" + 
						"    <!-- google font -->\r\n" + 
						"      <script type=\"text/javascript\">\r\n" + 
						"        function preventBack() { window.history.forward(); }\r\n" + 
						"        setTimeout(\"preventBack()\", 0);\r\n" + 
						"        window.onunload = function () { null };\r\n" + 
						"    </script><link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Kreon:300,400,700'>\r\n" + 
						"    \r\n" + 
						"    <!-- js -->\r\n" + 
						"   \r\n" + 
						"</head>");
				out.println("<body data-spy=\"scroll\" data-target=\"#navbar\" data-offset=\"120\" >\r\n" + 
						"\r\n" + 
						"\r\n" + 
						"\r\n" + 
						"\r\n" + 
						" <div id=\"special-offser\" class=\"parallax pricing\">");
				out.println(" <div class=\"row\">\r\n" + 
						"			   <div class=\"col-md-2 col-sm-2\">\r\n" + 
						"			    <a href=\"index.html\">LOGOUT</a>  </div>\r\n" + 
						"       <div class=\"container inner\">");
				if(userid.equals("SLC"))
				{
					
					
					
					try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
					Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
					PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
				//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
					stmt.setString(1,myName);
					stmt.setString(2,userid);
					stmt.setInt(3,pass);
					stmt.setTimestamp(4,getCurrentTimeStamp());
					int i=stmt.executeUpdate();  
					con.close(); }
					catch(Exception e){ System.out.println(e);} 
					
					
					
				//	try{Class.forName("oracle.jdbc.driver.OracleDriver"); 
				//	c =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","deepak","deepak");
					
					//Statement stmt=c.createStatement();
					
			//		stmt.executeUpdate("insert into order3 values('"+myName+"','"+userid+"',"+pass+")");}
				//	catch(Exception e)
			//		{System.out.println(e);}
				if(pass>=10)
				{	 k=pass*77;
				out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " SILICAN PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
				out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
						"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
						"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
						"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
						"            \r\n" + 
						"           \r\n" + 
						"             \r\n" + 
						"           \r\n" + 
						"        <!-- /.container --> \r\n" + 
						"    </div><!-- /#special-offser -->\r\n" + 
						"\r\n" + 
						"</div>\r\n" + 
						"</div>\r\n" + 
						"\r\n" + 
						"\r\n" + 
						"\r\n" + 
						"\r\n" + 
						"</body>\r\n" + 
						"</html>");
				}
				else{
					
					 k=pass*150;
						out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " SILICAN PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
						out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
								"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
								"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
								"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
								"            \r\n" + 
								"           \r\n" + 
								"             \r\n" + 
								"           \r\n" + 
								"        <!-- /.container --> \r\n" + 
								"    </div><!-- /#special-offser -->\r\n" + 
								"\r\n" + 
								"</div>\r\n" + 
								"</div>\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"</body>\r\n" + 
								"</html>");
				}}
				
				else{
					if(userid.equals("TNDRI"))
					{
						try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
						Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
						PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
					//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
						stmt.setString(1,myName);
						stmt.setString(2,userid);
						stmt.setInt(3,pass);
						stmt.setTimestamp(4,getCurrentTimeStamp());
						int i=stmt.executeUpdate();  
						con.close(); }
						catch(Exception e){ System.out.println(e);} 
						if(pass>=10)
						{	 k=pass*88;
					
						out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED " + pass + " TANDOORI PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
						out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
								"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
								"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
								"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
								"            \r\n" + 
								"           \r\n" + 
								"             \r\n" + 
								"           \r\n" + 
								"        <!-- /.container --> \r\n" + 
								"    </div><!-- /#special-offser -->\r\n" + 
								"\r\n" + 
								"</div>\r\n" + 
								"</div>\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"\r\n" + 
								"</body>\r\n" + 
								"</html>");
							//out.println("your total bill is:"+k);
							
						}
						else{
							
							 k=pass*160;
								out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " TANDOORI PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
								out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
										"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
										"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
										"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
										"            \r\n" + 
										"           \r\n" + 
										"             \r\n" + 
										"           \r\n" + 
										"        <!-- /.container --> \r\n" + 
										"    </div><!-- /#special-offser -->\r\n" + 
										"\r\n" + 
										"</div>\r\n" + 
										"</div>\r\n" + 
										"\r\n" + 
										"\r\n" + 
										"\r\n" + 
										"\r\n" + 
										"</body>\r\n" + 
										"</html>");
						}}
					else{
						if(userid.equals("NYK"))
						{
							try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
							Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
							PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
						//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
							stmt.setString(1,myName);
							stmt.setString(2,userid);
							stmt.setInt(3,pass);
							stmt.setTimestamp(4,getCurrentTimeStamp());
							int i=stmt.executeUpdate();  
							con.close(); }
							catch(Exception e){ System.out.println(e);} 
						 k=pass*170;
							out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED" + pass + " NEWYORK PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
							out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
									"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
									"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
									"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
									"            \r\n" + 
									"           \r\n" + 
									"             \r\n" + 
									"           \r\n" + 
									"        <!-- /.container --> \r\n" + 
									"    </div><!-- /#special-offser -->\r\n" + 
									"\r\n" + 
									"</div>\r\n" + 
									"</div>\r\n" + 
									"\r\n" + 
									"\r\n" + 
									"\r\n" + 
									"\r\n" + 
									"</body>\r\n" + 
									"</html>");
						}
						else{
							if(userid.equals("GRK"))
							{	try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
							Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
							PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
						//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
							stmt.setString(1,myName);
							stmt.setString(2,userid);
							stmt.setInt(3,pass);
							stmt.setTimestamp(4,getCurrentTimeStamp());
							int i=stmt.executeUpdate();  
							con.close(); }
							catch(Exception e){ System.out.println(e);} 
								 k=pass*180;
									out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " GREEK PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
									out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
											"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
											"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
											"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
											"            \r\n" + 
											"           \r\n" + 
											"             \r\n" + 
											"           \r\n" + 
											"        <!-- /.container --> \r\n" + 
											"    </div><!-- /#special-offser -->\r\n" + 
											"\r\n" + 
											"</div>\r\n" + 
											"</div>\r\n" + 
											"\r\n" + 
											"\r\n" + 
											"\r\n" + 
											"\r\n" + 
											"</body>\r\n" + 
											"</html>");
							}
							else{
								if(userid.equals("CLF"))
								{try{Class.forName("oracle.jdbc.driver.OracleDriver"); 
								c =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","deepak","deepak");
								
								Statement stmt=c.createStatement();
								
								stmt.executeUpdate("insert into order2 values('"+myName+"','"+userid+"',"+pass+")");}
								catch(Exception e)
								{System.out.println(e);}
									 k=pass*140;
										out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " CALIFORNIA PIZZAS.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
										out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
												"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
												"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
												"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
												"            \r\n" + 
												"           \r\n" + 
												"             \r\n" + 
												"           \r\n" + 
												"        <!-- /.container --> \r\n" + 
												"    </div><!-- /#special-offser -->\r\n" + 
												"\r\n" + 
												"</div>\r\n" + 
												"</div>\r\n" + 
												"\r\n" + 
												"\r\n" + 
												"\r\n" + 
												"\r\n" + 
												"</body>\r\n" + 
												"</html>");
								}
								else{
									if(userid.equals("CHGO"))
									{
										try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
										Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
										PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
									//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
										stmt.setString(1,myName);
										stmt.setString(2,userid);
										stmt.setInt(3,pass);
										stmt.setTimestamp(4,getCurrentTimeStamp());
										int i=stmt.executeUpdate();  
										con.close(); }
										catch(Exception e){ System.out.println(e);} 
										 k=pass*130;
											out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " CHICAGO PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
											out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
													"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
													"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
													"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
													"            \r\n" + 
													"           \r\n" + 
													"             \r\n" + 
													"           \r\n" + 
													"        <!-- /.container --> \r\n" + 
													"    </div><!-- /#special-offser -->\r\n" + 
													"\r\n" + 
													"</div>\r\n" + 
													"</div>\r\n" + 
													"\r\n" + 
													"\r\n" + 
													"\r\n" + 
													"\r\n" + 
													"</body>\r\n" + 
													"</html>");
									}
									else{
										if(userid.equals("PNR"))
										{
											try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
											Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
											PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
										//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
											stmt.setString(1,myName);
											stmt.setString(2,userid);
											stmt.setInt(3,pass);
											stmt.setTimestamp(4,getCurrentTimeStamp());
											int i=stmt.executeUpdate();  
											con.close(); }
											catch(Exception e){ System.out.println(e);} 
											 k=pass*110;
												out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " PANNER PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
												out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
														"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
														"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
														"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
														"            \r\n" + 
														"           \r\n" + 
														"             \r\n" + 
														"           \r\n" + 
														"        <!-- /.container --> \r\n" + 
														"    </div><!-- /#special-offser -->\r\n" + 
														"\r\n" + 
														"</div>\r\n" + 
														"</div>\r\n" + 
														"\r\n" + 
														"\r\n" + 
														"\r\n" + 
														"\r\n" + 
														"</body>\r\n" + 
														"</html>");
										}
										else{
											if(userid.equals("NPLT"))
											{
												try{ Class.forName("oracle.jdbc.driver.OracleDriver"); 
												Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak"); 
												PreparedStatement stmt=con.prepareStatement("insert into order3 values(?,?,?,?)");
											//	stmt.setInt(1,101);//1 specifies the first parameter in the query 
												stmt.setString(1,myName);
												stmt.setString(2,userid);
												stmt.setInt(3,pass);
												stmt.setTimestamp(4,getCurrentTimeStamp());
												int i=stmt.executeUpdate();  
												con.close(); }
												catch(Exception e){ System.out.println(e);} 
												 k=pass*100;
													out.println(" <h2 class=\"section-title text-center\">YOU HAVE ORDERED "+ pass + " NEAPOLITAN PIZZA.AND TOTAL AMMOUNT IS:"+k+"RS</h2>");
													out.println(" <h2 class=\"section-title text-center\">YOUR ORDER IS READY WITH IN THE 15 MINUTES</h2>\r\n" + 
															"		     <h2 class=\"section-title text-center\">THANK YOU</h2>\r\n" + 
															"			  <h2 class=\"section-title text-center\">WE ARE WAITING FOR YOUR NEXT ORDER</h2>\r\n" + 
															"            <p class=\"lead main text-center\">There is no sincerer love than the love of food!</p>\r\n" + 
															"            \r\n" + 
															"           \r\n" + 
															"             \r\n" + 
															"           \r\n" + 
															"        <!-- /.container --> \r\n" + 
															"    </div><!-- /#special-offser -->\r\n" + 
															"\r\n" + 
															"</div>\r\n" + 
															"</div>\r\n" + 
															"\r\n" + 
															"\r\n" + 
															"\r\n" + 
															"\r\n" + 
															"</body>\r\n" + 
															"</html>");
											
											}
											
											else {
												response.sendRedirect("wrongpromo.html"); 
											}
											
											
				}}}
										}}}}
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
