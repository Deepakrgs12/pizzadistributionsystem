package pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class del
 */
public class del extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String userid=request.getParameter("email");
		try{ Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection  ("jdbc:oracle:thin:@localhost:1521:xe","deepak","deepak");
		PreparedStatement stmt=con.prepareStatement("delete from order3 where email=?"); 
		stmt.setString(1,userid); 
		int i=stmt.executeUpdate(); 
		response.sendRedirect("confirmdelorder.html"); 
		//System.out.println(i+" records deleted"); 
		con.close(); }
		catch(Exception e){ System.out.println(e);} 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
